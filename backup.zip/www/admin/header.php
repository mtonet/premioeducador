<!DOCTYPE html>
<html lang="pt">
	<head>
		<meta charset="utf-8">
		<title>Prêmio Victor Civita</title>
		<script type="text/javascript" src="assets/js/simpletabs_1.1.js"></script>
		<link rel="stylesheet" type="text/css" href="assets/css/simpletabs.css">
		<script type="text/javascript" src="assets/js/bootstrap.js"></script>
		<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
		<style type="text/css">
			[class^="icon-"].done, [class*=" icon-"].done {
				background-image: url("assets/img/glyphicons-halflings-green.png");
			}
		</style>
		
		<script><?php $Site = array('url' => 'http://localhost/pvc/'); ?>
			Site = {};
			Site.url = '<?php $Site['url'] ?>';
		</script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
	</head>

	<body>
		<div class="container">
			<section class="main">