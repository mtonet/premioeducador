<?php
	define('DAO', $_SERVER['DOCUMENT_ROOT'] . 'pvc/dao/');
	define('ABSPATH', dirname(__FILE__).'/');
	define('CONFIG_HOST','localhost');
	define('TITLE_RELEASE','RELEASE');
	define('DESCRIPTION_RELEASE','Veja aqui as novidades da PepsiCo. Os releases est�o em ordem cronol�gica. Para obter releases mais antigos ou sobre outros assuntos que n�o foram abordados aqui, por favor envie um e-mail para <a href=\"mailto:debora.aguiar@edelman.com \">debora.aguiar@edelman.com </a>.');
	define('CONFIG_PAGINACAO_SITE',15);
?>