<img src="http://www.inscricoespremioeducador.com.br/assets/img/Logo-todos-educacao.png" alt="" usemap="#Map" width="153px" height="530px" border="0">
<map name="Map" id="Map"><area shape="rect" coords="20,152,128,190" href="http://www.tam.com.br/" target="_blank" />
  <area shape="rect" coords="7,29,68,60" href="http://www.fvc.org.br/" target="_blank"  />
  <area shape="rect" coords="87,27,128,66" href="http://www.frm.org.br/" target="_blank"  />
  <area shape="rect" coords="10,102,67,143" href="http://www.atica.com.br/" target="_blank"  />
  <area shape="rect" coords="80,99,141,142" href="http://www.scipione.com.br/" target="_blank"  />
  <area shape="rect" coords="19,289,134,330" href="http://www.unesco.org.br/" target="_blank"  />
  <area shape="rect" coords="19,213,127,251" href="http://www.gerdau.com.br/" target="_blank" />
<area shape="rect" coords="8,338,69,383" href="http://www.todospelaeducacao.org.br/" target="_blank"  />
  <area shape="rect" coords="86,337,145,379" href="http://www.consed.org.br/" target="_blank"  />
  <area shape="rect" coords="16,388,127,410" href="http://www.institutonatura.org.br/" target="_blank"  />
  <area shape="rect" coords="10,426,86,461" href="http://www.unicef.org.br/" target="_blank"  />
  <area shape="rect" coords="94,418,147,466" href="http://www.undime.org.br/" target="_blank" />
</map>
