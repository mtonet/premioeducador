﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.Web.Script.Services.ScriptService] //### importante descomentar esta linha ###
public class WebService : System.Web.Services.WebService {

    public WebService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    #region Reorder
    [WebMethod(EnableSession = true)]
    public string Reorder(object objOrdem)
    {
        string[] s = objOrdem.ToString().Split(',');
        int i = 1;
        foreach (string item in s)
        {
            AtualizarOrdem(Convert.ToInt32(item), i);
            i++;
        }
        return string.Empty;
    }
    #endregion

    #region AtualizarOrdem
    private void AtualizarOrdem(int iID, int iOrder)
    {
        string sConnectionString = "server=186.202.152.123;User Id=excellencebrok;password=ale2404;Persist Security Info=True;database=excellencebrok";
        using (MySqlConnection Conn = new MySqlConnection(sConnectionString))
        {
            string sSQL = "";// @"UPDATE tbimovelgaleria SET gal_ordem_img = @ordem WHERE gal_codigo = @id";
            MySqlCommand myCommand = new MySqlCommand(sSQL, Conn);
            myCommand.Parameters.AddWithValue("id", iID);
            myCommand.Parameters.AddWithValue("ordem", iOrder);
            Conn.Open();
            myCommand.ExecuteNonQuery();
            Conn.Close();
        }
    }
    #endregion
}
