﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Net.Mail;
using System.Configuration;
using System.Net;
using System.Text;
using System.IO;

public partial class Timer : System.Web.UI.Page
{

    public int cont = 1;

    string retorno = "";
    string nome = "";
    string id = "";

    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {
            Label1.Text = cont.ToString();
            Timer1.Interval = 70000;
        }

    }
    
    private string UpdateTimer(string contador)
    {
        string retorno = "";

        int cont1 = Convert.ToInt32(cotacaoDolar.Text) + 1;
        cotacaoDolar.Text = cont1.ToString();


        if (cont1 == 1)
        {
            Label1.Text = chadadados();
         //   retorno = EnviaChamadaUrl(Label1.Text);
            
 
        }
        else
        {
            Label1.Text = chadadadosProx(Label1.Text);
        //    retorno = EnviaChamadaUrl(Label1.Text);
        }


        return retorno;
    }




    public string EnviaChamadaUrl(string id)
    {
        string retorno = "";
        string sCaminhoDoArquivo = "http://www.inscricoespremioeducador.com.br/admin/envia_certificado.php?action="+id;

        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.Load(sCaminhoDoArquivo); //Carregando o arquivo

        //Pegando elemento pelo nome da TAG
        XmlNodeList xnList = xmlDoc.GetElementsByTagName("contato");

        //Usando foreach para imprimir na tela
        foreach (XmlNode xn in xnList)
        {
            string sNome = xn["nome"].InnerText;
            string sEmail = xn["email"].InnerText;
            retorno = sNome + sEmail;

          //  Response.Write("Nome: " + sNome + " Email: " + sEmail + "<br />");
        }

        return retorno;
    }


    protected void Timer1_Tick(object sender, EventArgs e)
    {
        cont++;
        TextBox1.Text = UpdateTimer(cont.ToString());
        horaAtualizacao.Text = DateTime.Now.ToLongTimeString();
        
    }


    public string chadadados()
    {

        string email = "";


       // string sConnectionString = "server=186.202.152.123;User Id=excellencebrok;password=ale2404;Persist Security Info=True;database=excellencebrok";
        string sConnectionString = "server=mysql03-farm25.uni5.net;User Id=inscricoespvc204;password=pvc220;Persist Security Info=True;database=inscricoespvc204";
        
        
        using (MySqlConnection Conn = new MySqlConnection(sConnectionString))
        {
            Conn.Open();
            //string sSQL = @"select gal_imo_codigo from tbimovelgaleria order by gal_ordem_img limit 1";

            string sSQL = @"SELECT id FROM vw_inscrito WHERE  ultimo_passo='7'  AND inscricao_status =2 ORDER BY id limit 1";

            MySqlCommand myCommand = new MySqlCommand(sSQL, Conn);

            myCommand.CommandText = sSQL;
            myCommand.CommandType = System.Data.CommandType.Text;
            myCommand.Connection = Conn;
            MySqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

            while (reader.Read())
            {
                retorno = reader["id"].ToString();
                id = reader["id"].ToString();
                nome = reader["nome"].ToString();
                email = reader["email"].ToString();

                //nome, $id, "alesenna@gmail.com"

                EnviaHTML(id, nome, email);

            }
                Conn.Close();
            }

            return retorno;

    }


    public string chadadadosProx(string regnum)
    {

        string retorno = "";
        // string sConnectionString = "server=186.202.152.123;User Id=excellencebrok;password=ale2404;Persist Security Info=True;database=excellencebrok";
        string sConnectionString = "server=mysql03-farm25.uni5.net;User Id=inscricoespvc204;password=pvc220;Persist Security Info=True;database=inscricoespvc204";
      
        using (MySqlConnection Conn = new MySqlConnection(sConnectionString))
        {
            Conn.Open();
           // string sSQL = @"SELECT gal_codigo FROM tbimovelgaleria WHERE gal_codigo>" + regnum + " ORDER BY gal_codigo ASC LIMIT 1";

            string sSQL = @"SELECT id FROM vw_inscrito WHERE id>" + regnum + " and ultimo_passo='7'  AND inscricao_status =2 ORDER BY id limit 1";

            
            
            MySqlCommand myCommand = new MySqlCommand(sSQL, Conn);

            myCommand.CommandText = sSQL;
            myCommand.CommandType = System.Data.CommandType.Text;
            myCommand.Connection = Conn;
            MySqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection);

            while (reader.Read())
            {
                retorno = reader["id"].ToString();

                id = reader["id"].ToString();
                nome = reader["nome"].ToString();
                email = reader["email"].ToString();

                //nome, $id, "alesenna@gmail.com"

                EnviaHTML(id, nome, email);
            }
                Conn.Close();
            }

            return retorno;

    }


    public void EnviaHTML(string ID, string nome, string email)
    {
        string html = lerHtml();
        string conteudo = html.Replace("%nome%", nome);
        conteudo = conteudo.Replace("%id%",ID);

        enviaMensagemEmail("premio@fvc.org.br", "alesenna@gmail.com", "", "", "Certificado de Participação 17º Prêmio Educador Nota 10", conteudo);

    }

    

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        Timer1.Interval = 70000;
        Timer1.Enabled = true;
    }


    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        Timer1.Interval = 10000;
        Timer1.Enabled = true;
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       // EnviaChamadaUrl(Label1.Text);
       // chadadados();
      //  TextBox1.Text = TextBox1.Text + "\n" +EnviaChamadaUrl(Label1.Text);

    }



    public string lerHtml()
    {

        WebRequest req = WebRequest.Create("http://inscricoespvc2014.com.br/enviocertificado.html");
        WebResponse res = req.GetResponse();
        StreamReader sr = new StreamReader(res.GetResponseStream());
        string retorno = sr.ReadToEnd();

        return retorno;
    }





    public string enviaMensagemEmail(string Remetente, string destino, string bcc, string cc, string assunto, string body)
    {


        string retorno = "";
        string servidorSMTP = "smtp.inscricoespvc2012.com.br";


        MailMessage mMailMessage = new MailMessage();

        // Define o endereço do remetente
        mMailMessage.From = new MailAddress(Remetente);

        // Define o destinario da mensagem
        mMailMessage.To.Add(new MailAddress(destino));


        // Verifica se o valor para bcc é null ou uma string vazia
        if ((bcc != null) & bcc != string.Empty)
        {
            // Define o endereço bcc
            mMailMessage.Bcc.Add(new MailAddress(bcc));
        }

        // verifica se o valor para cc é nulo ou uma string vazia
        if ((cc != null) & cc != string.Empty)
        {
            //Define o endereço cc
            mMailMessage.CC.Add(new MailAddress(cc));
        }

        //Define o assunto
        mMailMessage.Subject = assunto;

        //Define o corpo da mensagem
        mMailMessage.Body = body;

        //Define o formato do email como HTML
        mMailMessage.IsBodyHtml = true;

        // Define a prioridade da mensagem como normal
        mMailMessage.Priority = MailPriority.Normal;


        // Cria uma instância de SmtpClient - Nota - Define qual o host a ser usado para envio
        // de mensagens, no local de smtp.server.com use o nome do SEU servidor
        SmtpClient mSmtpClient = new SmtpClient(servidorSMTP);
        mSmtpClient.Credentials = new System.Net.NetworkCredential("email@inscricoespvc2012.com.br", "336699");


        mSmtpClient.Port = 587;

        // Envia o email

        try
        {
            mSmtpClient.Send(mMailMessage);
            retorno = "Email enviado com sucesso !!!";

        }
        catch (Exception ex)
        {
            retorno = ex.ToString();
        }


        return retorno;

    }










}